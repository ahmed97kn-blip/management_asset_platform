import { Employee, Department } from '@/types/employee';

// Default departments - customize as needed
export const mockDepartments: Department[] = [
  { id: '1', name: 'IT' },
  { id: '2', name: 'HR' },
  { id: '3', name: 'Sales' },
  { id: '4', name: 'Marketing' },
  { id: '5', name: 'Finance' },
  { id: '6', name: 'Operations' },
];

// Empty employee list for production - add your real employees here
export const mockEmployees: Employee[] = [];
