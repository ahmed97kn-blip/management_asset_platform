import { Package, Laptop, Monitor, Smartphone, CheckCircle, AlertTriangle, Users, Building2, Search, X, Archive } from 'lucide-react';
import { StatCard } from '@/components/StatCard';
import { MovementHistory } from '@/components/MovementHistory';
import { AssetTable } from '@/components/AssetTable';
import { AssetFilters } from '@/components/AssetFilters';
import { AssignDialog } from '@/components/AssignDialog';
import { ReturnDialog } from '@/components/ReturnDialog';
import { EditAssetDialog } from '@/components/EditAssetDialog';
import { Asset, AssetType, Movement } from '@/types/asset';
import { useToast } from '@/hooks/use-toast';
import { useData } from '@/contexts/DataContext';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type StatusFilter = 'all' | 'available' | 'maintenance' | 'retired';

export default function Dashboard() {
  const { toast } = useToast();
  const { assets, setAssets, movements, setMovements, employees, departments } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<AssetType | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<StatusFilter>('all');
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [userSearch, setUserSearch] = useState('');

  const stats = {
    total: assets.length,
    laptops: assets.filter((a) => a.type === 'laptop').length,
    screens: assets.filter((a) => a.type === 'screen').length,
    simCards: assets.filter((a) => a.type === 'sim_card').length,
    available: assets.filter((a) => a.status === 'available').length,
    maintenance: assets.filter((a) => a.status === 'maintenance').length,
    retired: assets.filter((a) => a.status === 'retired').length,
    employees: employees.length,
    departments: departments.length,
  };

  const handleStatClick = (type: AssetType | 'all', status: StatusFilter) => {
    // If clicking the same filter, reset to show all
    if (selectedType === type && selectedStatus === status) {
      setSelectedType('all');
      setSelectedStatus('all');
    } else {
      setSelectedType(type);
      setSelectedStatus(status);
    }
  };

  const filteredAssets = assets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.assignedTo?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || asset.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || asset.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleAssign = (asset: Asset) => {
    setSelectedAsset(asset);
    setAssignDialogOpen(true);
  };

  const handleReturn = (asset: Asset) => {
    setSelectedAsset(asset);
    setReturnDialogOpen(true);
  };

  const handleEdit = (asset: Asset) => {
    setSelectedAsset(asset);
    setEditDialogOpen(true);
  };

  const handleSaveEdit = (updatedAsset: Asset) => {
    setAssets(assets.map((a) => (a.id === updatedAsset.id ? updatedAsset : a)));
    toast({
      title: 'Asset Updated',
      description: `${updatedAsset.name} has been updated.`,
    });
  };

  const confirmAssign = (asset: Asset, userName: string, location: string, notes: string, driveLink: string): Movement => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { 
            ...a, 
            status: 'assigned' as const, 
            assignedTo: userName, 
            assignedDate: new Date().toISOString().split('T')[0],
            location: location
          }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'assign',
      toUser: userName,
      location: location,
      date: new Date().toISOString().split('T')[0],
      notes,
      driveLink: driveLink || undefined,
    };
    setMovements([newMovement, ...movements]);
    
    toast({
      title: 'Asset Assigned',
      description: `${asset.name} has been assigned to ${userName}.`,
    });

    return newMovement;
  };

  const confirmReturn = (asset: Asset, location: string, notes: string, driveLink: string): Movement => {
    const previousUser = asset.assignedTo;
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { 
            ...a, 
            status: 'available' as const, 
            assignedTo: undefined, 
            assignedDate: undefined,
            location: location
          }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'return',
      fromUser: previousUser,
      location: location,
      date: new Date().toISOString().split('T')[0],
      notes,
      driveLink: driveLink || undefined,
    };
    setMovements([newMovement, ...movements]);
    
    toast({
      title: 'Asset Returned',
      description: `${asset.name} has been returned to inventory.`,
    });

    return newMovement;
  };

  const handleRetire = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'retired' as const, assignedTo: undefined, assignedDate: undefined }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'maintenance',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset moved out of service',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Asset Retired',
      description: `${asset.name} has been moved out of service.`,
    });
  };

  const handleMaintenance = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'maintenance' as const }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'maintenance',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset sent for maintenance',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Maintenance Mode',
      description: `${asset.name} has been sent for maintenance.`,
    });
  };

  const handleRestoreFromMaintenance = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'available' as const }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'return',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset fixed and returned to available',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Asset Fixed',
      description: `${asset.name} is now available again.`,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your IT assets</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8">
        <StatCard 
          title="Total Assets" 
          value={stats.total} 
          icon={Package} 
          onClick={() => handleStatClick('all', 'all')}
          isActive={selectedType === 'all' && selectedStatus === 'all'}
        />
        <StatCard 
          title="Laptops" 
          value={stats.laptops} 
          icon={Laptop} 
          onClick={() => handleStatClick('laptop', 'all')}
          isActive={selectedType === 'laptop' && selectedStatus === 'all'}
        />
        <StatCard 
          title="Screens" 
          value={stats.screens} 
          icon={Monitor} 
          onClick={() => handleStatClick('screen', 'all')}
          isActive={selectedType === 'screen' && selectedStatus === 'all'}
        />
        <StatCard 
          title="SIM Cards" 
          value={stats.simCards} 
          icon={Smartphone} 
          onClick={() => handleStatClick('sim_card', 'all')}
          isActive={selectedType === 'sim_card' && selectedStatus === 'all'}
        />
        <StatCard 
          title="Available" 
          value={stats.available} 
          icon={CheckCircle} 
          onClick={() => handleStatClick('all', 'available')}
          isActive={selectedStatus === 'available'}
        />
        <StatCard 
          title="Maintenance" 
          value={stats.maintenance} 
          icon={AlertTriangle} 
          onClick={() => handleStatClick('all', 'maintenance')}
          isActive={selectedStatus === 'maintenance'}
        />
        <StatCard 
          title="Out of Service" 
          value={stats.retired} 
          icon={Archive} 
          onClick={() => handleStatClick('all', 'retired')}
          isActive={selectedStatus === 'retired'}
        />
        <StatCard title="Employees" value={stats.employees} icon={Users} />
      </div>

      {/* User Asset Search */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search Assets by User</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Enter employee name..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            {userSearch && (
              <Button variant="ghost" size="icon" onClick={() => setUserSearch('')}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          {userSearch && (
            <div className="mt-4">
              {(() => {
                const userAssets = assets.filter(
                  (a) => a.assignedTo?.toLowerCase().includes(userSearch.toLowerCase())
                );
                if (userAssets.length === 0) {
                  return (
                    <p className="text-sm text-muted-foreground">
                      No assets found for "{userSearch}"
                    </p>
                  );
                }
                return (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">
                      Found {userAssets.length} asset(s) assigned to users matching "{userSearch}":
                    </p>
                    <div className="rounded-md border">
                      <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                          <tr>
                            <th className="p-2 text-left font-medium">Asset</th>
                            <th className="p-2 text-left font-medium">Type</th>
                            <th className="p-2 text-left font-medium">Serial</th>
                            <th className="p-2 text-left font-medium">Assigned To</th>
                            <th className="p-2 text-left font-medium">Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {userAssets.map((asset) => (
                            <tr key={asset.id} className="border-t">
                              <td className="p-2">{asset.name}</td>
                              <td className="p-2 capitalize">{asset.type.replace('_', ' ')}</td>
                              <td className="p-2 font-mono text-muted-foreground">{asset.serialNumber}</td>
                              <td className="p-2">{asset.assignedTo}</td>
                              <td className="p-2 text-muted-foreground">{asset.assignedDate || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <AssetFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedType={selectedType}
            onTypeChange={setSelectedType}
          />
          <AssetTable
            assets={filteredAssets}
            onAssign={handleAssign}
            onReturn={handleReturn}
            onEdit={handleEdit}
            onRetire={handleRetire}
            onMaintenance={handleMaintenance}
            onRestoreFromMaintenance={handleRestoreFromMaintenance}
          />
        </div>
        <div>
          <MovementHistory movements={movements.slice(0, 5)} />
        </div>
      </div>

      <AssignDialog
        asset={selectedAsset}
        open={assignDialogOpen}
        onOpenChange={setAssignDialogOpen}
        onConfirm={confirmAssign}
      />

      <ReturnDialog
        asset={selectedAsset}
        open={returnDialogOpen}
        onOpenChange={setReturnDialogOpen}
        onConfirm={confirmReturn}
      />

      <EditAssetDialog
        asset={selectedAsset}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSave={handleSaveEdit}
      />
    </div>
  );
}
