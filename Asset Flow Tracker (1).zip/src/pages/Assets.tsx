import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AssetTable } from '@/components/AssetTable';
import { AssetFilters } from '@/components/AssetFilters';
import { AssignDialog } from '@/components/AssignDialog';
import { ReturnDialog } from '@/components/ReturnDialog';
import { AddAssetDialog } from '@/components/AddAssetDialog';
import { EditAssetDialog } from '@/components/EditAssetDialog';
import { Asset, AssetType, Movement } from '@/types/asset';
import { useToast } from '@/hooks/use-toast';
import { useData } from '@/contexts/DataContext';

export default function Assets() {
  const { toast } = useToast();
  const { assets, setAssets, movements, setMovements } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<AssetType | 'all'>('all');
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);

  const filteredAssets = assets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.assignedTo?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || asset.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleAssign = (asset: Asset) => {
    setSelectedAsset(asset);
    setAssignDialogOpen(true);
  };

  const handleReturn = (asset: Asset) => {
    setSelectedAsset(asset);
    setReturnDialogOpen(true);
  };

  const handleEdit = (asset: Asset) => {
    setSelectedAsset(asset);
    setEditDialogOpen(true);
  };

  const handleSaveEdit = (updatedAsset: Asset) => {
    setAssets(assets.map((a) => (a.id === updatedAsset.id ? updatedAsset : a)));
    toast({
      title: 'Asset Updated',
      description: `${updatedAsset.name} has been updated.`,
    });
  };

  const confirmAssign = (asset: Asset, userName: string, location: string, notes: string, driveLink: string): Movement => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { 
            ...a, 
            status: 'assigned' as const, 
            assignedTo: userName, 
            assignedDate: new Date().toISOString().split('T')[0],
            location: location
          }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'assign',
      toUser: userName,
      location: location,
      date: new Date().toISOString().split('T')[0],
      notes,
      driveLink: driveLink || undefined,
    };
    setMovements([newMovement, ...movements]);
    
    toast({
      title: 'Asset Assigned',
      description: `${asset.name} has been assigned to ${userName}.`,
    });

    return newMovement;
  };

  const confirmReturn = (asset: Asset, location: string, notes: string, driveLink: string): Movement => {
    const previousUser = asset.assignedTo;
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { 
            ...a, 
            status: 'available' as const, 
            assignedTo: undefined, 
            assignedDate: undefined,
            location: location
          }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'return',
      fromUser: previousUser,
      location: location,
      date: new Date().toISOString().split('T')[0],
      notes,
      driveLink: driveLink || undefined,
    };
    setMovements([newMovement, ...movements]);
    
    toast({
      title: 'Asset Returned',
      description: `${asset.name} has been returned to inventory.`,
    });

    return newMovement;
  };

  const handleRetire = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'retired' as const, assignedTo: undefined, assignedDate: undefined }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'maintenance',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset moved out of service',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Asset Retired',
      description: `${asset.name} has been moved out of service.`,
    });
  };

  const handleMaintenance = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'maintenance' as const }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'maintenance',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset sent for maintenance',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Maintenance Mode',
      description: `${asset.name} has been sent for maintenance.`,
    });
  };

  const handleRestoreFromMaintenance = (asset: Asset) => {
    const updatedAssets = assets.map((a) =>
      a.id === asset.id
        ? { ...a, status: 'available' as const }
        : a
    );
    setAssets(updatedAssets);

    const newMovement: Movement = {
      id: String(Date.now()),
      assetId: asset.id,
      assetName: asset.name,
      assetSerialNumber: asset.serialNumber,
      type: 'return',
      location: asset.location,
      date: new Date().toISOString().split('T')[0],
      notes: 'Asset fixed and returned to available',
    };
    setMovements([newMovement, ...movements]);

    toast({
      title: 'Asset Fixed',
      description: `${asset.name} is now available again.`,
    });
  };

  const handleAddAsset = (newAsset: Omit<Asset, 'id'>) => {
    const asset: Asset = {
      ...newAsset,
      id: String(Date.now()),
    };
    setAssets([asset, ...assets]);
    
    toast({
      title: 'Asset Added',
      description: `${asset.name} has been added to inventory.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Assets</h1>
          <p className="text-muted-foreground">Manage your IT asset inventory</p>
        </div>
        <Button onClick={() => setAddDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Asset
        </Button>
      </div>

      <AssetFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedType={selectedType}
        onTypeChange={setSelectedType}
      />

      <AssetTable
        assets={filteredAssets}
        onAssign={handleAssign}
        onReturn={handleReturn}
        onEdit={handleEdit}
        onRetire={handleRetire}
        onMaintenance={handleMaintenance}
        onRestoreFromMaintenance={handleRestoreFromMaintenance}
      />

      <AddAssetDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onAdd={handleAddAsset}
      />

      <EditAssetDialog
        asset={selectedAsset}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSave={handleSaveEdit}
      />

      <AssignDialog
        asset={selectedAsset}
        open={assignDialogOpen}
        onOpenChange={setAssignDialogOpen}
        onConfirm={confirmAssign}
      />

      <ReturnDialog
        asset={selectedAsset}
        open={returnDialogOpen}
        onOpenChange={setReturnDialogOpen}
        onConfirm={confirmReturn}
      />
    </div>
  );
}
