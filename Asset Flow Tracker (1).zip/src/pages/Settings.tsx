import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Trash2, Users, Building2, MapPin, Pencil, LogOut } from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Settings() {
  const { toast } = useToast();
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { 
    employees, addEmployee, deleteEmployee, 
    departments, addDepartment, deleteDepartment, 
    locations, addLocation, updateLocation, deleteLocation,
    assets 
  } = useData();

  const handleLogout = () => {
    logout();
    navigate('/login');
    toast({
      title: 'Logged Out',
      description: 'You have been logged out successfully.',
    });
  };
  
  // Employee form state
  const [employeeDialogOpen, setEmployeeDialogOpen] = useState(false);
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    email: '',
    department: '',
    position: '',
    phone: '',
    startDate: '',
  });
  
  // Department form state
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [newDepartmentName, setNewDepartmentName] = useState('');

  // Location form state
  const [locationDialogOpen, setLocationDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<{ id: string; name: string; description: string } | null>(null);
  const [newLocation, setNewLocation] = useState({ name: '', description: '' });

  const handleAddEmployee = () => {
    if (!newEmployee.name || !newEmployee.email || !newEmployee.department || !newEmployee.position || !newEmployee.startDate) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }
    
    addEmployee({
      name: newEmployee.name,
      email: newEmployee.email,
      department: newEmployee.department,
      position: newEmployee.position,
      phone: newEmployee.phone || undefined,
      startDate: newEmployee.startDate,
    });
    
    toast({
      title: 'Employee Added',
      description: `${newEmployee.name} has been added to the employee list.`,
    });
    
    setNewEmployee({ name: '', email: '', department: '', position: '', phone: '', startDate: '' });
    setEmployeeDialogOpen(false);
  };

  const handleDeleteEmployee = (id: string, name: string) => {
    const hasAssignedAssets = assets.some((asset) => asset.assignedTo === name);
    if (hasAssignedAssets) {
      toast({
        title: 'Cannot Delete',
        description: `${name} has assets assigned. Return the assets first.`,
        variant: 'destructive',
      });
      return;
    }
    deleteEmployee(id);
    toast({
      title: 'Employee Removed',
      description: `${name} has been removed from the employee list.`,
    });
  };

  const handleAddDepartment = () => {
    if (!newDepartmentName.trim()) {
      toast({
        title: 'Missing name',
        description: 'Please enter a department name.',
        variant: 'destructive',
      });
      return;
    }
    
    const exists = departments.some(
      (dept) => dept.name.toLowerCase() === newDepartmentName.trim().toLowerCase()
    );
    if (exists) {
      toast({
        title: 'Duplicate',
        description: 'This department already exists.',
        variant: 'destructive',
      });
      return;
    }
    
    addDepartment(newDepartmentName.trim());
    toast({
      title: 'Department Added',
      description: `${newDepartmentName.trim()} has been added.`,
    });
    setNewDepartmentName('');
    setDepartmentDialogOpen(false);
  };

  const handleDeleteDepartment = (id: string, name: string) => {
    const hasEmployees = employees.some((emp) => emp.department === name);
    if (hasEmployees) {
      toast({
        title: 'Cannot Delete',
        description: `${name} has employees assigned. Reassign them first.`,
        variant: 'destructive',
      });
      return;
    }
    deleteDepartment(id);
    toast({
      title: 'Department Removed',
      description: `${name} has been removed.`,
    });
  };

  const handleAddOrUpdateLocation = () => {
    if (!newLocation.name.trim()) {
      toast({
        title: 'Missing name',
        description: 'Please enter a location name.',
        variant: 'destructive',
      });
      return;
    }

    if (editingLocation) {
      updateLocation(editingLocation.id, { 
        name: newLocation.name.trim(), 
        description: newLocation.description.trim() || undefined 
      });
      toast({
        title: 'Location Updated',
        description: `${newLocation.name.trim()} has been updated.`,
      });
    } else {
      const exists = locations.some(
        (loc) => loc.name.toLowerCase() === newLocation.name.trim().toLowerCase()
      );
      if (exists) {
        toast({
          title: 'Duplicate',
          description: 'This location already exists.',
          variant: 'destructive',
        });
        return;
      }
      
      addLocation(newLocation.name.trim(), newLocation.description.trim() || undefined);
      toast({
        title: 'Location Added',
        description: `${newLocation.name.trim()} has been added.`,
      });
    }
    
    setNewLocation({ name: '', description: '' });
    setEditingLocation(null);
    setLocationDialogOpen(false);
  };

  const handleEditLocation = (location: { id: string; name: string; description?: string }) => {
    setEditingLocation({ id: location.id, name: location.name, description: location.description || '' });
    setNewLocation({ name: location.name, description: location.description || '' });
    setLocationDialogOpen(true);
  };

  const handleDeleteLocation = (id: string, name: string) => {
    const hasAssets = assets.some((asset) => asset.location === name);
    if (hasAssets) {
      toast({
        title: 'Cannot Delete',
        description: `${name} has assets assigned. Reassign them first.`,
        variant: 'destructive',
      });
      return;
    }
    deleteLocation(id);
    toast({
      title: 'Location Removed',
      description: `${name} has been removed.`,
    });
  };

  const handleLocationDialogChange = (open: boolean) => {
    if (!open) {
      setNewLocation({ name: '', description: '' });
      setEditingLocation(null);
    }
    setLocationDialogOpen(open);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage employees, departments, locations, and preferences</p>
      </div>

      <Tabs defaultValue="employees" className="space-y-4">
        <TabsList>
          <TabsTrigger value="employees" className="gap-2">
            <Users className="h-4 w-4" />
            Employees
          </TabsTrigger>
          <TabsTrigger value="departments" className="gap-2">
            <Building2 className="h-4 w-4" />
            Departments
          </TabsTrigger>
          <TabsTrigger value="locations" className="gap-2">
            <MapPin className="h-4 w-4" />
            Locations
          </TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        <TabsContent value="employees" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Employee List</h2>
              <p className="text-sm text-muted-foreground">
                {employees.length} employees registered
              </p>
            </div>
            <Dialog open={employeeDialogOpen} onOpenChange={setEmployeeDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Employee
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Employee</DialogTitle>
                  <DialogDescription>
                    Add a new employee to the system.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="emp-name">Name *</Label>
                      <Input
                        id="emp-name"
                        value={newEmployee.name}
                        onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="emp-email">Email *</Label>
                      <Input
                        id="emp-email"
                        type="email"
                        value={newEmployee.email}
                        onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                        placeholder="john@company.com"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="emp-department">Department *</Label>
                      <Select
                        value={newEmployee.department}
                        onValueChange={(value) => setNewEmployee({ ...newEmployee, department: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map((dept) => (
                            <SelectItem key={dept.id} value={dept.name}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="emp-position">Position *</Label>
                      <Input
                        id="emp-position"
                        value={newEmployee.position}
                        onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })}
                        placeholder="Software Engineer"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="emp-phone">Phone</Label>
                      <Input
                        id="emp-phone"
                        value={newEmployee.phone}
                        onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })}
                        placeholder="+1 555-0100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="emp-start">Start Date *</Label>
                      <Input
                        id="emp-start"
                        type="date"
                        value={newEmployee.startDate}
                        onChange={(e) => setNewEmployee({ ...newEmployee, startDate: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setEmployeeDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddEmployee}>Add Employee</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="rounded-md border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {employees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell className="font-medium">{employee.name}</TableCell>
                    <TableCell className="text-muted-foreground">{employee.email}</TableCell>
                    <TableCell>{employee.department}</TableCell>
                    <TableCell>{employee.position}</TableCell>
                    <TableCell>{employee.phone || '—'}</TableCell>
                    <TableCell>{employee.startDate}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleDeleteEmployee(employee.id, employee.name)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="departments" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Departments</h2>
              <p className="text-sm text-muted-foreground">
                {departments.length} departments configured
              </p>
            </div>
            <Dialog open={departmentDialogOpen} onOpenChange={setDepartmentDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Department
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Department</DialogTitle>
                  <DialogDescription>
                    Add a new department to the system.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="dept-name">Department Name</Label>
                    <Input
                      id="dept-name"
                      value={newDepartmentName}
                      onChange={(e) => setNewDepartmentName(e.target.value)}
                      placeholder="e.g., Engineering"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDepartmentDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddDepartment}>Add Department</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-3 max-w-md">
            {departments.map((dept) => {
              const empCount = employees.filter((e) => e.department === dept.name).length;
              return (
                <div
                  key={dept.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-card"
                >
                  <div>
                    <p className="font-medium">{dept.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {empCount} employee{empCount !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => handleDeleteDepartment(dept.id, dept.name)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="locations" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Locations</h2>
              <p className="text-sm text-muted-foreground">
                {locations.length} locations configured
              </p>
            </div>
            <Dialog open={locationDialogOpen} onOpenChange={handleLocationDialogChange}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Location
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingLocation ? 'Edit Location' : 'Add New Location'}</DialogTitle>
                  <DialogDescription>
                    {editingLocation ? 'Update the location details.' : 'Add a new location to the system.'}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="loc-name">Location Name *</Label>
                    <Input
                      id="loc-name"
                      value={newLocation.name}
                      onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
                      placeholder="e.g., Baghdad Office"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="loc-desc">Description</Label>
                    <Input
                      id="loc-desc"
                      value={newLocation.description}
                      onChange={(e) => setNewLocation({ ...newLocation, description: e.target.value })}
                      placeholder="e.g., Main headquarters"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => handleLocationDialogChange(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddOrUpdateLocation}>
                    {editingLocation ? 'Update Location' : 'Add Location'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-3 max-w-md">
            {locations.map((loc) => {
              const assetCount = assets.filter((a) => a.location === loc.name).length;
              return (
                <div
                  key={loc.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-card"
                >
                  <div>
                    <p className="font-medium">{loc.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {loc.description || 'No description'} • {assetCount} asset{assetCount !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleEditLocation(loc)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => handleDeleteLocation(loc.id, loc.name)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-4">
          <div className="grid gap-6 max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Configure how you receive notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive email alerts for asset movements
                    </p>
                  </div>
                  <Switch id="email-notifications" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="maintenance-alerts">Maintenance Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified when assets require maintenance
                    </p>
                  </div>
                  <Switch id="maintenance-alerts" defaultChecked />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
                <CardDescription>Manage your asset data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auto-archive">Auto-archive Retired Assets</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically archive assets marked as retired after 30 days
                    </p>
                  </div>
                  <Switch id="auto-archive" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-destructive/20">
              <CardHeader>
                <CardTitle>Session</CardTitle>
                <CardDescription>Manage your current session</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Log Out</Label>
                    <p className="text-sm text-muted-foreground">
                      End your session and return to login
                    </p>
                  </div>
                  <Button variant="destructive" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Log Out
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
