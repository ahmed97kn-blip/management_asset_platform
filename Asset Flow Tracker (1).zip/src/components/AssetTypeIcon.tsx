import { Laptop, Monitor, Smartphone } from 'lucide-react';
import { AssetType } from '@/types/asset';

interface AssetTypeIconProps {
  type: AssetType;
  className?: string;
}

export function AssetTypeIcon({ type, className = "h-5 w-5" }: AssetTypeIconProps) {
  switch (type) {
    case 'laptop':
      return <Laptop className={className} />;
    case 'screen':
      return <Monitor className={className} />;
    case 'sim_card':
      return <Smartphone className={className} />;
    default:
      return <Laptop className={className} />;
  }
}

export function getAssetTypeLabel(type: AssetType): string {
  switch (type) {
    case 'laptop':
      return 'Laptop';
    case 'screen':
      return 'Screen';
    case 'sim_card':
      return 'SIM Card';
    default:
      return type;
  }
}
