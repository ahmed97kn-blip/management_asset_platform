import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Asset, Movement } from '@/types/asset';
import { useData } from '@/contexts/DataContext';

interface ReturnDialogProps {
  asset: Asset | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (asset: Asset, location: string, notes: string, driveLink: string) => Movement;
}

export function ReturnDialog({ asset, open, onOpenChange, onConfirm }: ReturnDialogProps) {
  const { locations } = useData();
  const [selectedLocationId, setSelectedLocationId] = useState('');
  const [notes, setNotes] = useState('');
  const [driveLink, setDriveLink] = useState('');
  const [lastMovement, setLastMovement] = useState<Movement | null>(null);
  const [showPaperOption, setShowPaperOption] = useState(false);

  const handleConfirm = () => {
    const selectedLocation = locations.find((loc) => loc.id === selectedLocationId);
    if (asset && selectedLocation) {
      const movement = onConfirm(asset, selectedLocation.name, notes.trim(), driveLink.trim());
      setLastMovement(movement);
      setShowPaperOption(true);
    }
  };

  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      setSelectedLocationId('');
      setNotes('');
      setDriveLink('');
      setShowPaperOption(false);
      setLastMovement(null);
    }
    onOpenChange(isOpen);
  };

  const handlePrintPaper = () => {
    if (asset && lastMovement) {
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Asset Return Form</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
              .header { text-align: center; border-bottom: 2px solid #1e3a5f; padding-bottom: 20px; margin-bottom: 30px; }
              .header h1 { color: #1e3a5f; margin: 0; font-size: 24px; }
              .header p { color: #666; margin: 5px 0 0; }
              .section { margin-bottom: 25px; }
              .section-title { font-weight: bold; color: #1e3a5f; border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-bottom: 15px; }
              .field { display: flex; margin-bottom: 10px; }
              .field-label { font-weight: 500; width: 150px; color: #444; }
              .field-value { flex: 1; border-bottom: 1px dotted #999; padding-left: 10px; }
              .signatures { display: flex; gap: 50px; margin-top: 60px; }
              .signature-box { flex: 1; text-align: center; }
              .signature-line { border-top: 1px solid #333; margin-top: 60px; padding-top: 10px; }
              .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
              .terms { font-size: 12px; color: #555; }
              .terms ul { padding-left: 20px; }
              @media print { body { padding: 20px; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>Digital Zone - IT Asset Management</h1>
              <p>Asset Return Acknowledgment Form</p>
            </div>

            <div class="section">
              <div class="section-title">Document Information</div>
              <div class="field">
                <span class="field-label">Document No:</span>
                <span class="field-value">DZ-RTN-${lastMovement.id.padStart(6, '0')}</span>
              </div>
              <div class="field">
                <span class="field-label">Date:</span>
                <span class="field-value">${new Date(lastMovement.date).toLocaleDateString('en-GB')}</span>
              </div>
            </div>

            <div class="section">
              <div class="section-title">Asset Details</div>
              <div class="field">
                <span class="field-label">Asset Name:</span>
                <span class="field-value">${asset.name}</span>
              </div>
              <div class="field">
                <span class="field-label">Serial Number:</span>
                <span class="field-value">${asset.serialNumber}</span>
              </div>
              <div class="field">
                <span class="field-label">Asset Type:</span>
                <span class="field-value">${asset.type.replace('_', ' ').toUpperCase()}</span>
              </div>
              <div class="field">
                <span class="field-label">Return Location:</span>
                <span class="field-value">${lastMovement.location || 'N/A'}</span>
              </div>
            </div>

            <div class="section">
              <div class="section-title">Return Details</div>
              <div class="field">
                <span class="field-label">Returned By:</span>
                <span class="field-value">${lastMovement.fromUser}</span>
              </div>
              <div class="field">
                <span class="field-label">Notes:</span>
                <span class="field-value">${lastMovement.notes || 'N/A'}</span>
              </div>
            </div>

            <div class="section terms">
              <div class="section-title">Confirmation</div>
              <ul>
                <li>The IT department confirms receipt of the above-mentioned asset.</li>
                <li>The asset has been inspected and its condition noted.</li>
                <li>The employee is released from responsibility for this asset.</li>
              </ul>
            </div>

            <div class="signatures">
              <div class="signature-box">
                <div class="signature-line">
                  <strong>Returning Employee</strong><br>
                  <span style="font-size: 12px; color: #666;">Signature & Date</span>
                </div>
              </div>
              <div class="signature-box">
                <div class="signature-line">
                  <strong>IT Department</strong><br>
                  <span style="font-size: 12px; color: #666;">Signature & Date</span>
                </div>
              </div>
            </div>

            <div class="footer">
              <p>Digital Zone - IT Asset Management System</p>
              <p>This document is auto-generated and valid without signature for internal records.</p>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
    handleOpenChange(false);
  };

  if (showPaperOption && lastMovement) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Asset Returned Successfully</DialogTitle>
            <DialogDescription>
              {asset?.name} has been returned to inventory.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 text-center space-y-4">
            <p className="text-muted-foreground">
              Would you like to print the Asset Return Form?
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              Close
            </Button>
            <Button onClick={handlePrintPaper}>
              Print Return Form
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Return Asset</DialogTitle>
          <DialogDescription>
            Return "{asset?.name}" from {asset?.assignedTo}.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="returnLocation">Return to Location *</Label>
            <Select value={selectedLocationId} onValueChange={setSelectedLocationId}>
              <SelectTrigger>
                <SelectValue placeholder="Select return location" />
              </SelectTrigger>
              <SelectContent>
                {locations.map((location) => (
                  <SelectItem key={location.id} value={location.id}>
                    {location.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="returnNotes">Notes (optional)</Label>
            <Textarea
              id="returnNotes"
              placeholder="Add any notes about the return..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="returnDriveLink">Google Drive Link (Legal Paper)</Label>
            <input
              id="returnDriveLink"
              type="url"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="https://drive.google.com/..."
              value={driveLink}
              onChange={(e) => setDriveLink(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleConfirm} disabled={!selectedLocationId}>
            Confirm Return
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
