import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Laptop, Monitor, Smartphone } from 'lucide-react';
import { AssetType } from '@/types/asset';

interface AssetFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedType: AssetType | 'all';
  onTypeChange: (type: AssetType | 'all') => void;
}

const typeFilters: { value: AssetType | 'all'; label: string; icon?: typeof Laptop }[] = [
  { value: 'all', label: 'All' },
  { value: 'laptop', label: 'Laptops', icon: Laptop },
  { value: 'screen', label: 'Screens', icon: Monitor },
  { value: 'sim_card', label: 'SIM Cards', icon: Smartphone },
];

export function AssetFilters({
  searchQuery,
  onSearchChange,
  selectedType,
  onTypeChange,
}: AssetFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-4">
      <div className="relative flex-1 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search assets..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>
      <div className="flex gap-2">
        {typeFilters.map((filter) => {
          const Icon = filter.icon;
          return (
            <Button
              key={filter.value}
              variant={selectedType === filter.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => onTypeChange(filter.value)}
            >
              {Icon && <Icon className="h-4 w-4 mr-1" />}
              {filter.label}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
