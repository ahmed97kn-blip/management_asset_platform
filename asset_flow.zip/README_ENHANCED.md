# Asset Flow Tracker

A modern asset and inventory management application built with React, TypeScript, and shadcn/ui.

## 🚀 Features

- **Dashboard**: Overview of assets and movements with charts
- **Asset Management**: Track and manage your assets
- **Movement Tracking**: Monitor asset transfers and movements
- **Authentication**: Secure login system
- **Responsive Design**: Works on desktop and mobile

## 🛠️ Tech Stack

- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite
- **UI Library**: shadcn/ui + Radix UI
- **Styling**: Tailwind CSS
- **Routing**: React Router v6
- **State Management**: React Context + TanStack Query
- **Forms**: React Hook Form + Zod validation
- **Charts**: Recharts

## 📦 Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run tests
npm test
```

## 🌐 Deploy to Vercel

### Method 1: Deploy via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

### Method 2: Deploy via Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your repository
5. Vercel will auto-detect Vite settings
6. Click "Deploy"

### Method 3: One-Click Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=YOUR_REPO_URL)

## ⚙️ Environment Variables

Create a `.env` file in the root directory:

```env
VITE_APP_TITLE=Asset Flow Tracker
VITE_API_URL=your_api_url_here
```

## 📁 Project Structure

```
src/
├── components/       # Reusable UI components
├── contexts/         # React Context providers
├── hooks/           # Custom React hooks
├── layouts/         # Layout components
├── pages/           # Page components
├── types/           # TypeScript type definitions
├── lib/             # Utility functions
└── data/            # Mock data and constants
```

## 🔧 Configuration Files

- `vite.config.ts` - Vite configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration
- `vercel.json` - Vercel deployment configuration

## 📝 Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm test` - Run tests
- `npm run test:watch` - Run tests in watch mode

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License
