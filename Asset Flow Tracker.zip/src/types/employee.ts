export interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  position: string;
  phone?: string;
  startDate: string;
}

export interface Department {
  id: string;
  name: string;
}
