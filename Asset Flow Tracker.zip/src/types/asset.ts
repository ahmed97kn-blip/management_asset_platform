export type AssetType = 'laptop' | 'screen' | 'sim_card';
export type AssetStatus = 'available' | 'assigned' | 'maintenance' | 'retired';
export type MovementType = 'assign' | 'return' | 'transfer' | 'maintenance';

export interface Asset {
  id: string;
  type: AssetType;
  name: string;
  serialNumber: string;
  status: AssetStatus;
  assignedTo?: string;
  assignedDate?: string;
  location?: string;
  notes?: string;
  driveLink?: string;
  createdAt: string;
}

export interface Movement {
  id: string;
  assetId: string;
  assetName: string;
  assetSerialNumber: string;
  type: MovementType;
  fromUser?: string;
  toUser?: string;
  location?: string;
  date: string;
  notes?: string;
  driveLink?: string;
}
