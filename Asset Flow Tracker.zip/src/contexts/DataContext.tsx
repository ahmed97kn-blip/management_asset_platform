import { createContext, useContext, useState, ReactNode } from 'react';
import { Asset, Movement } from '@/types/asset';
import { Employee, Department } from '@/types/employee';
import { Location } from '@/types/location';
import { mockAssets, mockMovements } from '@/data/mockData';
import { mockEmployees, mockDepartments } from '@/data/employeeData';
import { mockLocations } from '@/data/locationData';

interface DataContextType {
  // Assets
  assets: Asset[];
  setAssets: React.Dispatch<React.SetStateAction<Asset[]>>;
  
  // Movements
  movements: Movement[];
  setMovements: React.Dispatch<React.SetStateAction<Movement[]>>;
  
  // Employees
  employees: Employee[];
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  updateEmployee: (id: string, employee: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  
  // Departments
  departments: Department[];
  addDepartment: (name: string) => void;
  deleteDepartment: (id: string) => void;
  
  // Locations
  locations: Location[];
  addLocation: (name: string, description?: string) => void;
  updateLocation: (id: string, updates: Partial<Location>) => void;
  deleteLocation: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [assets, setAssets] = useState<Asset[]>(mockAssets);
  const [movements, setMovements] = useState<Movement[]>(mockMovements);
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees);
  const [departments, setDepartments] = useState<Department[]>(mockDepartments);
  const [locations, setLocations] = useState<Location[]>(mockLocations);

  const addEmployee = (employee: Omit<Employee, 'id'>) => {
    const newEmployee: Employee = {
      ...employee,
      id: String(Date.now()),
    };
    setEmployees((prev) => [...prev, newEmployee]);
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setEmployees((prev) =>
      prev.map((emp) => (emp.id === id ? { ...emp, ...updates } : emp))
    );
  };

  const deleteEmployee = (id: string) => {
    setEmployees((prev) => prev.filter((emp) => emp.id !== id));
  };

  const addDepartment = (name: string) => {
    const newDepartment: Department = {
      id: String(Date.now()),
      name,
    };
    setDepartments((prev) => [...prev, newDepartment]);
  };

  const deleteDepartment = (id: string) => {
    setDepartments((prev) => prev.filter((dept) => dept.id !== id));
  };

  const addLocation = (name: string, description?: string) => {
    const newLocation: Location = {
      id: String(Date.now()),
      name,
      description,
    };
    setLocations((prev) => [...prev, newLocation]);
  };

  const updateLocation = (id: string, updates: Partial<Location>) => {
    setLocations((prev) =>
      prev.map((loc) => (loc.id === id ? { ...loc, ...updates } : loc))
    );
  };

  const deleteLocation = (id: string) => {
    setLocations((prev) => prev.filter((loc) => loc.id !== id));
  };

  return (
    <DataContext.Provider
      value={{
        assets,
        setAssets,
        movements,
        setMovements,
        employees,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        departments,
        addDepartment,
        deleteDepartment,
        locations,
        addLocation,
        updateLocation,
        deleteLocation,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
