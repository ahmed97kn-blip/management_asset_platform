import { useState } from 'react';
import { MovementType } from '@/types/asset';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, ArrowRightLeft, RotateCcw, Wrench, UserPlus } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { useData } from '@/contexts/DataContext';

const movementConfig: Record<MovementType, { icon: typeof ArrowRightLeft; label: string; variant: 'success' | 'default' | 'warning' | 'destructive' }> = {
  assign: { icon: UserPlus, label: 'Assigned', variant: 'success' },
  return: { icon: RotateCcw, label: 'Returned', variant: 'default' },
  transfer: { icon: ArrowRightLeft, label: 'Transferred', variant: 'warning' },
  maintenance: { icon: Wrench, label: 'Maintenance', variant: 'destructive' },
};

export default function Movements() {
  const { movements } = useData();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMovements = movements.filter((movement) =>
    movement.assetName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    movement.toUser?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    movement.fromUser?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Movement History</h1>
        <p className="text-muted-foreground">Track all asset movements and transfers</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search movements..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Asset</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>From</TableHead>
              <TableHead>To</TableHead>
              <TableHead>Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMovements.map((movement) => {
              const config = movementConfig[movement.type];
              const Icon = config.icon;
              
              return (
                <TableRow key={movement.id}>
                  <TableCell className="font-mono text-sm">
                    {new Date(movement.date).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="font-medium">{movement.assetName}</TableCell>
                  <TableCell>
                    <Badge variant={config.variant} className="flex items-center gap-1 w-fit">
                      <Icon className="h-3 w-3" />
                      {config.label}
                    </Badge>
                  </TableCell>
                  <TableCell>{movement.fromUser || '—'}</TableCell>
                  <TableCell>{movement.toUser || '—'}</TableCell>
                  <TableCell className="text-muted-foreground max-w-xs truncate">
                    {movement.notes || '—'}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
