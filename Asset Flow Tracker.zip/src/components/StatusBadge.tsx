import { Badge } from '@/components/ui/badge';
import { AssetStatus } from '@/types/asset';

interface StatusBadgeProps {
  status: AssetStatus;
}

const statusConfig: Record<AssetStatus, { label: string; variant: 'success' | 'warning' | 'destructive' | 'muted' }> = {
  available: { label: 'Available', variant: 'success' },
  assigned: { label: 'Assigned', variant: 'warning' },
  maintenance: { label: 'Maintenance', variant: 'destructive' },
  retired: { label: 'Retired', variant: 'muted' },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <Badge variant={config.variant}>
      {config.label}
    </Badge>
  );
}
