import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Asset } from '@/types/asset';
import { StatusBadge } from './StatusBadge';
import { AssetTypeIcon, getAssetTypeLabel } from './AssetTypeIcon';
import { ArrowRightLeft, RotateCcw, MoreHorizontal, Pencil, ExternalLink, Archive, Wrench, CheckCircle } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface AssetTableProps {
  assets: Asset[];
  onAssign: (asset: Asset) => void;
  onReturn: (asset: Asset) => void;
  onEdit: (asset: Asset) => void;
  onRetire?: (asset: Asset) => void;
  onMaintenance?: (asset: Asset) => void;
  onRestoreFromMaintenance?: (asset: Asset) => void;
}

export function AssetTable({ assets, onAssign, onReturn, onEdit, onRetire, onMaintenance, onRestoreFromMaintenance }: AssetTableProps) {
  return (
    <div className="rounded-md border bg-card">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Type</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Serial Number</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Assigned To</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Notes</TableHead>
            <TableHead>Drive Link</TableHead>
            <TableHead>Date Added</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {assets.map((asset) => (
            <TableRow key={asset.id}>
              <TableCell>
                <div className="flex items-center gap-2">
                  <AssetTypeIcon type={asset.type} className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{getAssetTypeLabel(asset.type)}</span>
                </div>
              </TableCell>
              <TableCell className="font-medium">{asset.name}</TableCell>
              <TableCell className="font-mono text-sm text-muted-foreground">
                {asset.serialNumber}
              </TableCell>
              <TableCell>
                <StatusBadge status={asset.status} />
              </TableCell>
              <TableCell>{asset.assignedTo || '—'}</TableCell>
              <TableCell>{asset.location || '—'}</TableCell>
              <TableCell className="max-w-[150px] truncate text-sm text-muted-foreground" title={asset.notes}>
                {asset.notes || '—'}
              </TableCell>
              <TableCell>
                {asset.driveLink ? (
                  <a
                    href={asset.driveLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                  >
                    <ExternalLink className="h-3 w-3" />
                    Open
                  </a>
                ) : (
                  '—'
                )}
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {asset.createdAt || '—'}
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(asset)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    {asset.status === 'available' && (
                      <>
                        <DropdownMenuItem onClick={() => onAssign(asset)}>
                          <ArrowRightLeft className="mr-2 h-4 w-4" />
                          Assign
                        </DropdownMenuItem>
                        {onMaintenance && (
                          <DropdownMenuItem onClick={() => onMaintenance(asset)}>
                            <Wrench className="mr-2 h-4 w-4" />
                            Maintenance
                          </DropdownMenuItem>
                        )}
                        {onRetire && (
                          <DropdownMenuItem onClick={() => onRetire(asset)}>
                            <Archive className="mr-2 h-4 w-4" />
                            Out of Service
                          </DropdownMenuItem>
                        )}
                      </>
                    )}
                    {asset.status === 'assigned' && (
                      <DropdownMenuItem onClick={() => onReturn(asset)}>
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Return
                      </DropdownMenuItem>
                    )}
                    {asset.status === 'maintenance' && onRestoreFromMaintenance && (
                      <DropdownMenuItem onClick={() => onRestoreFromMaintenance(asset)}>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Fixed - Back to Available
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
