import { Movement, MovementType } from '@/types/asset';
import { ArrowRightLeft, RotateCcw, Wrench, UserPlus, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface MovementHistoryProps {
  movements: Movement[];
}

const movementConfig: Record<MovementType, { icon: typeof ArrowRightLeft; label: string; color: string }> = {
  assign: { icon: UserPlus, label: 'Assigned', color: 'text-success' },
  return: { icon: RotateCcw, label: 'Returned', color: 'text-primary' },
  transfer: { icon: ArrowRightLeft, label: 'Transferred', color: 'text-warning' },
  maintenance: { icon: Wrench, label: 'Maintenance', color: 'text-destructive' },
};

export function MovementHistory({ movements }: MovementHistoryProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Movements</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {movements.map((movement) => {
            const config = movementConfig[movement.type];
            const Icon = config.icon;
            
            return (
              <div key={movement.id} className="flex items-start gap-3 pb-4 border-b last:border-0 last:pb-0">
                <div className={`p-2 rounded-full bg-muted ${config.color}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{movement.assetName}</p>
                  <p className="text-xs text-muted-foreground">
                    {config.label}
                    {movement.toUser && ` to ${movement.toUser}`}
                    {movement.fromUser && ` from ${movement.fromUser}`}
                  </p>
                  {movement.notes && (
                    <p className="text-xs text-muted-foreground mt-1">{movement.notes}</p>
                  )}
                  {movement.driveLink && (
                    <a
                      href={movement.driveLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Legal Paper
                    </a>
                  )}
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(movement.date).toLocaleDateString()}
                </span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
