import { Asset, Movement } from '@/types/asset';

// Empty data for production - add your real assets here
export const mockAssets: Asset[] = [];

export const mockMovements: Movement[] = [];
