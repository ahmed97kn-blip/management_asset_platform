import { Location } from '@/types/location';

export const mockLocations: Location[] = [
  { id: '1', name: 'Baghdad Office', description: 'Main headquarters' },
  { id: '2', name: 'Remote', description: 'Work from home' },
  { id: '3', name: 'Basra Office', description: 'Southern branch' },
  { id: '4', name: 'Erbil Office', description: 'Northern branch' },
];
